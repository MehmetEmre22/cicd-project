#!/bin/bash


echo "   Docker CI/CD Pipeline - Sistem Baslatiyor"
echo "------------------------------------------"

# 1. Sistemi ayaga kaldir
echo "[1/5] Servisler baslatiliyor..."
docker compose up -d

# 2. Servislerin ayaga kalkması için bekle
echo "[2/5] Servisler hazirlanıyor, 15 saniye bekleniyor..."
sleep 15

# 3. Tüm container durumlarını göster
echo "[3/5] Container durumlari kontrol ediliyor..."
docker ps

# 4. Gitea health check
echo "[4/5] Gitea kontrol ediliyor..."
curl -f http://localhost:3000 > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "✅ Gitea: HAZIR"
else
    echo "❌ Gitea: HAZIR DEĞİL — docker compose restart gitea"
fi

# 5. Nginx health check
echo "[5/5] Nginx kontrol ediliyor..."
curl -f http://localhost:80 > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "✅ Nginx: HAZIR"
else
    echo "❌ Nginx: HAZIR DEĞİL — docker compose restart nginx"
fi

echo "------------------------------------------"
echo "   Sistem Kontrolu Tamamlandi"
echo "   Gitea  : http://localhost:3000"
echo "   Drone  : http://localhost:8080"
echo "   Nginx  : http://localhost:80"
