
#bu script Task Scheduler (cron job) ile otomatikleştirilebilir.
#Bilgisayar açıldığında veya belirli bir saatte çalışacak şekilde ayarlanabilir. Tek kısıt Docker Desktop'ın açık olması gerektiğidir.

Write-Host "   Docker CI/CD Pipeline - Sistem Baslatiyor"
Write-Host "------------------------------------------"

# 1. Sistemi ayaga kaldir
Write-Host "[1/5] Servisler baslatiliyor..."
docker compose up -d

# 2. Servislerin hazirlanmasi icin bekle
Write-Host "[2/5] 15 saniye bekleniyor..."
Start-Sleep -Seconds 15

# 3. Container durumlarini goster
Write-Host "[3/5] Container durumlari:"
docker ps

# 4. Gitea health check
Write-Host "[4/5] Gitea kontrol ediliyor..."
try {
    $gitea = Invoke-WebRequest -Uri http://localhost:3000 -UseBasicParsing
    if ($gitea.StatusCode -eq 200) {
        Write-Host "[HAZIR] Gitea: HAZIR"
    }
} catch {
    Write-Host "[X] Gitea: HAZIR DEGIL"
}

# 5. Nginx health check
Write-Host "[5/5] Nginx kontrol ediliyor..."
try {
    $nginx = Invoke-WebRequest -Uri http://localhost:80 -UseBasicParsing
    if ($nginx.StatusCode -eq 200) {
        Write-Host "[HAZIR] Nginx: HAZIR"
    }
} catch {
    Write-Host "[X] Nginx: HAZIR DEGIL"
}

Write-Host "------------------------------------------"
Write-Host "   Gitea  : http://localhost:3000"
Write-Host "   Drone  : http://localhost:8080"
Write-Host "   Nginx  : http://localhost:80"
