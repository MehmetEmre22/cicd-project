# Docker CI/CD Pipeline Simülasyonu

<div align="center">

![Docker](https://img.shields.io/badge/Docker-2496ED?style=for-the-badge&logo=docker&logoColor=white)
![Gitea](https://img.shields.io/badge/Gitea-609926?style=for-the-badge&logo=gitea&logoColor=white)
![Drone CI](https://img.shields.io/badge/Drone_CI-212121?style=for-the-badge&logo=drone&logoColor=white)
![Flask](https://img.shields.io/badge/Flask-000000?style=for-the-badge&logo=flask&logoColor=white)
![Nginx](https://img.shields.io/badge/Nginx-009639?style=for-the-badge&logo=nginx&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)

<br/>

> Gitea · Drone CI · Flask · Nginx · Docker Compose
> Trakya Üniversitesi — Yazılım Mühendisliği Dönem Projesi · 2026

</div>

---

## Proje Hakkında

Bu proje, modern DevOps pratiklerini simüle eden tam işlevsel bir CI/CD pipeline'ıdır. Kaynak kod değişiklikleri commit anından itibaren otomatik olarak test edilir; testler geçerse uygulama kullanıcıya sunulur. Tüm sistem Docker container'ları üzerinde çalışır ve internet bağlantısına ihtiyaç duymaz.

---

## Mimari

```
  +-------------------------------------------------------+
  |              cicd-network  (Docker bridge)            |
  |                                                       |
  |   +-----------+   webhook    +--------------------+   |
  |   |           | -----------> |   Drone Server     |   |
  |   |   Gitea   |              |   localhost:8080   |   |
  |   | :3000/222 |              +--------------------+   |
  |   |           |                        |              |
  |   | Git repo  |              +----------v---------+   |
  |   | OAuth2    |              |   Drone Runner     |   |
  |   +-----------+              |                    |   |
  |                              | clone > test       |   |
  |                              |      > deploy      |   |
  |                              +--------------------+   |
  |                                        |              |
  |                              +----------v---------+   |
  |                              |   deploy_volume    |   |
  |                              +--------------------+   |
  |                                        |              |
  |   +-----------+   proxy      +----------v---------+   |
  |   |   Flask   | <----------- |      Nginx         |   |
  |   |   :5000   |              |      :80           |   |
  |   +-----------+              +--------------------+   |
  |                                                       |
  +-------------------------------------------------------+
```

---

## Pipeline Akışı

```
  Gelistirici
      |
      |  git push gitea master
      v
  +-------------------------------------------+
  |  GITEA                                    |
  |  Commit alindi -> webhook tetiklendi      |
  +-------------------------------------------+
      |
      v
  +-------------------------------------------+
  |  DRONE CI                                 |
  |                                           |
  |  Step 1 -- clone                          |
  |            alpine/git ile repo klonlanir  |
  |                |                          |
  |  Step 2 -- test                           |
  |            python:3.11                    |
  |            pip install + pytest           |
  |                |                          |
  |           +----+----+                     |
  |         FAILED    PASSED                  |
  |           |          |                    |
  |       pipeline   Step 3 -- deploy         |
  |        durur      alpine                  |
  |                   cp -r /src/* /deploy/   |
  +-------------------------------------------+
      |
      v
  +-------------------------------------------+
  |  NGINX  ->  localhost:80                  |
  |  {"message": "CI/CD Calisiyor v1.0"}      |
  +-------------------------------------------+
```

---

## Servisler

| Servis | Host Port | Container Port | Açıklama |
|--------|-----------|----------------|---------|
| Gitea | 3000, 222 | 3000, 22 | Self-hosted Git sunucusu |
| Drone Server | 8080 | 80 | Pipeline yönetimi ve arayüzü |
| Drone Runner | — | 3000 | Pipeline adımlarını çalıştırır |
| Flask | 5000 | 5000 | Demo web uygulaması |
| Nginx | 80 | 80 | Reverse proxy |

---

## Proje Yapısı

```
cicd-project/
|-- docker-compose.yml     # Tüm servislerin orkestrasyonu
|-- .drone.yml             # Pipeline as Code tanımı
|-- .env                   # Secrets (git'e gitmez)
|-- .gitignore
|-- startup.ps1            # Sunum günü sistem başlatma scripti
|-- app/
|   |-- app.py             # Flask uygulaması
|   |-- Dockerfile         # Uygulama container tarifi
|   |-- requirements.txt   # Python bağımlılıkları
|   +-- test_app.py        # pytest birim testleri
+-- nginx/
    +-- nginx.conf         # Reverse proxy konfigürasyonu
```

---

## Kurulum

### Gereksinimler

- [Docker Desktop](https://www.docker.com/products/docker-desktop/)
- Git

### 1 — Repoyu Klonla

```bash
git clone https://github.com/MuratcanKara/cicd-project.git
cd cicd-project
```

### 2 — `.env` Dosyasını Oluştur

```env
DRONE_GITEA_CLIENT_ID=gitea_kurulumundan_gelecek
DRONE_GITEA_CLIENT_SECRET=gitea_kurulumundan_gelecek
GITEA_ADMIN_USER=gitea-admin
GITEA_ADMIN_PASSWORD=sifreniz
DRONE_RPC_SECRET=guclu_rastgele_deger
DRONE_SERVER_HOST=localhost:8080
DRONE_SERVER_PROTO=http
```

### 3 — Windows Hosts Dosyasına Gitea Ekle

PowerShell'i yönetici olarak aç:

```powershell
Add-Content -Path "C:\Windows\System32\drivers\etc\hosts" -Value "127.0.0.1 gitea"
```

### 4 — Sistemi Başlat

```bash
docker compose up -d
```

### 5 — Gitea'yı Yapılandır

`http://localhost:3000` adresinden kurulum sihirbazını tamamla, admin hesabı oluştur, `cicd-org` organizasyonu ve `sample-app` reposu oluştur, Drone CI için OAuth2 uygulaması kaydet.

### 6 — Drone'u Yapılandır

`http://localhost:8080` adresinden Gitea OAuth2 ile giriş yap, `cicd-org/sample-app` reposunu sync et, aktif et ve Trusted olarak işaretle.

### 7 — Kodu Gitea'ya Push Et

```bash
git remote add gitea http://KULLANICI:SIFRE@localhost:3000/cicd-org/sample-app.git
git push gitea master
```

---

## Uygulanan DevOps Prensipleri

| Prensip | Uygulama |
|---------|---------|
| **Pipeline as Code** | `.drone.yml` kaynak kodla birlikte versiyonlanır |
| **Fail-fast** | Test başarısız olursa deploy aşamasına geçilmez |
| **Secrets Management** | Hassas değerler `.env` dosyasında, kodda hardcode yok |
| **Immutable Infrastructure** | Her build temiz ve izole bir container ortamında çalışır |
| **Separation of Concerns** | Her servis kendi container'ında, her rol kendi dosyasında |
| **Infrastructure as Code** | Tüm altyapı `docker-compose.yml` ile kod olarak tanımlı |

---

## Performans

| Metrik | Değer |
|--------|-------|
| Pipeline süresi — pip cache yok | ~17 saniye |
| Pipeline süresi — pip cache ile | ~10 saniye |
| Cache hızlanması | %41 |
| Sistem recovery süresi (MTTR) | ~35 saniye |
| İnternet bağımlılığı | Yok |

---

## Ekip

| İsim | Rol |
|------|-----|
| Başak Selin Sertel | SCM Mühendisi — Gitea, OAuth2, versiyon kontrol |
| Muratcan Kara | DevOps Altyapı Mühendisi — Orkestrasyon, network, secrets |
| Mehmet Emre Sipahioğlu | CI Mühendisi — Drone CI/Runner, pipeline tasarımı |
| Sude Çiçek Koçak | CD & Release Mühendisi — Nginx, reverse proxy, deploy |
| Elif Altun | App & Container Mühendisi — Flask, Dockerfile, pytest |

---

*Trakya Üniversitesi · Yazılım Mühendisliği · 2026*