# Drone CI — CI Katmanı

Bu klasör Drone CI'a ait konfigürasyon notlarını ve kurulum belgelerini içerir. Pipeline tanımı ise proje kök dizinindeki `.drone.yml` dosyasında yer alır.

---

## Drone CI Nedir?

Drone CI, "şu olay olduğunda, şu işleri sırayla yap" mantığıyla çalışan bir otomasyon motorudur. Bu projede Gitea'ya her commit atıldığında devreye girer ve pipeline'ı çalıştırır.

Drone iki bileşenden oluşur:

| Bileşen | Görev |
|---------|-------|
| **Drone Server** | Gitea'dan webhook alır, pipeline'ı yönetir, web arayüzünü sunar |
| **Drone Runner** | Server'dan emir alır, container başlatır, adımları çalıştırır |

---

## Servis Bilgileri

### Drone Server

| Özellik | Değer |
|---------|-------|
| Image | `drone/drone:2` |
| Web arayüzü | `http://localhost:8080` |
| Container içi port | `80` |
| Volume | `drone_data:/data` |
| Network | `cicd-network` |

### Drone Runner

| Özellik | Değer |
|---------|-------|
| Image | `drone/drone-runner-docker:1` |
| Network | `cicd-network` |
| Özel ayar | `privileged: true` |
| Docker socket | `/var/run/docker.sock` mount'u gerekli |

---

## Kritik Environment Variable'lar

```env
# Drone Server
DRONE_GITEA_SERVER=http://gitea:3000       # Gitea adresi (container içi)
DRONE_GITEA_CLIENT_ID=...                  # Gitea OAuth2'den üretilir
DRONE_GITEA_CLIENT_SECRET=...              # Gitea OAuth2'den üretilir
DRONE_RPC_SECRET=...                       # Server-Runner arası şifreli iletişim
DRONE_SERVER_HOST=localhost:8080           # Dışarıdan erişim adresi
DRONE_SERVER_PROTO=http
DRONE_USER_CREATE=username:gitea-admin,admin:true  # İlk kullanıcıya admin yetkisi

# Drone Runner
DRONE_RPC_HOST=drone                       # Server servis ismi
DRONE_RPC_PROTO=http
DRONE_RPC_SECRET=...                       # Server ile aynı değer olmalı
DRONE_RUNNER_CAPACITY=2                    # Eş zamanlı pipeline sayısı
DRONE_RUNNER_NETWORKS=cicd-project_cicd-network  # Step container'larının ağı
```

---

## Kurulum Adımları

### 1. Gitea OAuth2 değerlerini al

Gitea kurulumu tamamlandıktan sonra `DRONE_GITEA_CLIENT_ID` ve `DRONE_GITEA_CLIENT_SECRET` değerlerini `.env` dosyasına ekle.

### 2. Drone'u başlat

```bash
docker compose up -d drone
```

### 3. Gitea ile giriş yap

`http://localhost:8080` → **Continue** → Gitea kullanıcı adı ve şifresiyle giriş yap → kayıt formunu doldur.

### 4. Repoyu aktif et

`http://localhost:8080` → **Sync** → `cicd-org/sample-app` → **Activate Repository**

### 5. Trusted ayarını aç

`cicd-org/sample-app` → **Settings** → **Trusted** toggle'ı aç → **Save Changes**

> Bu ayar olmadan pipeline host volume'larına erişemez ve deploy adımı başarısız olur.

### 6. Gitea token'ını secret olarak ekle

`cicd-org/sample-app` → **Settings** → **Secrets**

| Alan | Değer |
|------|-------|
| Name | `gitea_token` |
| Value | Gitea'dan üretilen access token |

Bu token `.drone.yml` içinde clone adımında kullanılır:

```yaml
environment:
  GITEA_TOKEN:
    from_secret: gitea_token
```

---

## Pipeline Tanımı (.drone.yml)

Pipeline tanımı proje kök dizinindeki `.drone.yml` dosyasındadır. Drone bu dosyayı Gitea'dan otomatik okur.

### Adımlar

**clone** — Gitea'daki `sample-app` reposu alpine/git ile klonlanır. Varsayılan Drone clone mekanizması devre dışı bırakılmıştır (`clone: disable: true`), çünkü container içinden `localhost` erişimi çalışmaz; token tabanlı özel clone kullanılır.

**test** — `python:3.11` container'ında bağımlılıklar yüklenir ve pytest çalıştırılır. `pip_cache` volume'u bağlanarak tekrarlı indirmeler önlenir.

**deploy** — Testler geçerse dosyalar `deploy_volume`'a kopyalanır. Bu volume Nginx container'ı tarafından okunur ve `localhost:80` üzerinden sunulur. `when: status: [success]` koşuluyla yalnızca başarılı build'lerde çalışır.

### Pip Cache

```yaml
volumes:
  - name: pip_cache
    host:
      path: /var/lib/docker/volumes/cicd-project_pip_cache/_data
```

Test adımında `/root/.cache/pip` dizini bu volume'a bağlanır. İlk çalışmada paketler indirilip cache'e yazılır, sonraki çalışmalarda internet yerine cache kullanılır.

| Durum | Süre |
|-------|------|
| Cache olmadan | ~17 saniye |
| Cache ile | ~10 saniye |

---

## Webhook Bağlantısı

Drone, repo aktif edildiğinde Gitea'ya otomatik webhook kaydeder. Ancak bu webhook URL'si `localhost:8080` kullanır — container içinden erişilemez.

Manuel düzeltme için:

```
Gitea → cicd-org/sample-app → Settings → Webhooks
URL: http://localhost:8080/hook?secret=...
          ↓
URL: http://drone:80/hook?secret=...
```

> Port farkına dikkat: `8080` host portu, `80` container portu. Container'lar arası iletişimde container portu kullanılır.

---

## Drone Log'larını Okuma

```bash
# Drone Server logları
docker compose logs drone --tail=50

# Drone Runner logları
docker compose logs drone-runner --tail=50
```

| Log satırı | Anlamı |
|------------|--------|
| `successfully pinged the remote server` | Runner, Server'a başarıyla bağlandı |
| `polling the remote server` | Runner iş bekliyor |
| `starting the http server` | Server ayağa kalktı |
| `interrupt received` | Servis durduruldu |

---

## Sık Karşılaşılan Sorunlar

**`untrusted repositories cannot mount host volumes`**
→ Drone arayüzünde repo Settings → Trusted toggle'ı aç.

**`could not read Username for 'http://localhost:3000'`**
→ Gitea ROOT_URL'i `http://gitea:3000/` olarak güncelle.

**`dial tcp: connect: connection refused` (webhook)**
→ Webhook URL'ini `http://drone:80/hook?secret=...` olarak güncelle.

**`webhook can only call allowed HTTP servers`**
→ Gitea `app.ini` dosyasına `ALLOWED_HOST_LIST = drone` ekle.