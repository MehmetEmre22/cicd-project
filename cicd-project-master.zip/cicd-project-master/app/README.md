# Docker CI/CD Pipeline Simülasyonu

Trakya Üniversitesi — Yazılım Mühendisliği Dönem Projesi

## Proje Hakkında
Gitea + Drone CI + Flask + Nginx + Docker Compose ile
tam işlevsel bir CI/CD pipeline simülasyonu.

## Ekip
- Öğrenci 1 — SCM Mühendisi
- Öğrenci 2 — CI Mühendisi
- Öğrenci 3 — App & Container Mühendisi
- Öğrenci 4 — CD & Release Mühendisi
- Öğrenci 5 — DevOps Altyapı Mühendisi

## Servisler
| Servis    | Port |
|-----------|------|
| Gitea     | 3000 |
| Drone CI  | 8080 |
| Flask App | 5000 |
| Nginx     | 80   |

## Başlatmak İçin
docker compose up -d