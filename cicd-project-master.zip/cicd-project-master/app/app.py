from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return jsonify({"message": "CI/CD Çalışıyor v1.0"}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)