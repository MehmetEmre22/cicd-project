import pytest
from app import app

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_index_json_validation(client):
    response = client.get('/')
    data = response.get_json()
    
    assert response.status_code == 200
    assert "message" in data
    assert data["message"] == "CI/CD Çalışıyor v1.0"
