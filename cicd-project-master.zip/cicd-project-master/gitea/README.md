# Gitea — SCM Katmanı

Bu klasör Gitea'ya ait konfigürasyon şablonlarını ve kurulum notlarını içerir.

---

## Gitea Nedir?

Gitea, self-hosted (kendi sunucunda barındırılan) bir Git sunucusudur. GitHub ile aynı işlevi görür — repo oluşturma, commit atma, kod paylaşma — ancak internet üzerinde değil, kendi makinende çalışır.

Bu projede Gitea'nın tercih edilmesinin sebebi, Drone CI'ın webhook alabilmesi için dışarıdan erişilebilir bir URL gerektirmesidir. GitHub bu koşulu localhost ortamında sağlayamaz.

---

## Servis Bilgileri

| Özellik | Değer |
|---------|-------|
| Image | `gitea/gitea:latest` |
| Web arayüzü | `http://localhost:3000` |
| SSH portu | `localhost:222` |
| Container içi port | `3000` |
| Volume | `gitea_data:/data` |
| Network | `cicd-network` |

---

## Kurulum Adımları

### 1. Sistemi başlat

```bash
docker compose up -d
```

### 2. Kurulum sihirbazını tamamla

`http://localhost:3000` adresini aç. Hiçbir ayarı değiştirmeden **Install Gitea** butonuna bas. Administrator Account Settings bölümünden admin hesabını oluştur.

### 3. Organizasyon ve repo oluştur

- **Organization:** `cicd-org`
- **Repository:** `cicd-org/sample-app`
- Repository oluştururken **Initialize Repository** seçeneğini işaretle.

### 4. OAuth2 uygulaması kaydet

`http://localhost:3000/-/user/settings/applications` adresine git.

| Alan | Değer |
|------|-------|
| Application Name | `drone-ci` |
| Redirect URI | `http://localhost:8080/login` |

Oluşturulan **Client ID** ve **Client Secret** değerlerini `.env` dosyasına yaz:

```env
DRONE_GITEA_CLIENT_ID=...
DRONE_GITEA_CLIENT_SECRET=...
```

### 5. Access token oluştur

Drone'un clone işlemi için Gitea'ya erişmesi gerekir.

`http://localhost:3000/user/settings/applications` → **Generate New Token**

| Alan | Değer |
|------|-------|
| Token Name | `drone-clone` |
| Repository izni | Read |

Oluşturulan token'ı Drone arayüzünde `cicd-org/sample-app` → Settings → Secrets bölümüne ekle:

- **Name:** `gitea_token`
- **Value:** oluşturulan token

---

## Kritik Konfigürasyon: ROOT_URL

Gitea varsayılan olarak `ROOT_URL = http://localhost:3000/` kullanır. Bu değer container içinden erişilemez. Drone'un clone işlemi yapabilmesi için `http://gitea:3000/` olarak değiştirilmesi gerekir.

```bash
# app.ini dosyasındaki ROOT_URL değerini güncelle
docker exec -it -u git gitea sed -i \
  's|ROOT_URL = http://localhost:3000/|ROOT_URL = http://gitea:3000/|g' \
  /data/gitea/conf/app.ini

# Gitea'yı yeniden başlat
docker compose restart gitea
```

---

## Kritik Konfigürasyon: Webhook İzni

Gitea varsayılan olarak webhook'ların yalnızca belirli adreslere istek atmasına izin verir. Drone'a izin vermek için:

```bash
docker exec -it -u git gitea sh -c \
  "echo '[webhook]' >> /data/gitea/conf/app.ini && \
   echo 'ALLOWED_HOST_LIST = drone' >> /data/gitea/conf/app.ini"

docker compose restart gitea
```

---

## Webhook Ayarı

Drone, `sample-app` reposunu aktif ettiğinde webhook URL'sini otomatik oluşturur. Ancak bu URL `localhost:8080` kullanır — container içinden erişilemez. Manuel olarak düzeltilmesi gerekir.

`http://localhost:3000/cicd-org/sample-app/settings/hooks` → webhook'u düzenle

| Alan | Yanlış | Doğru |
|------|--------|-------|
| URL | `http://localhost:8080/hook?secret=...` | `http://drone:80/hook?secret=...` |

---

## Veri Kalıcılığı

Gitea verileri `gitea_data` named volume'unda saklanır. `docker compose down` yapıldığında container silinse bile tüm repolar, kullanıcılar ve ayarlar korunur.

```bash
# Veri kalıcılığını doğrula
docker exec -it -u git gitea cat /data/gitea/conf/app.ini | findstr ROOT_URL
# docker compose down && docker compose up -d sonrasında aynı değer görünmeli
```

---

## Konfigürasyon Şablonu

`app.ini.example` dosyası, projedeki kritik Gitea ayarlarını belgeler. Gerçek `app.ini` dosyası Gitea container'ı içinde `/data/gitea/conf/app.ini` konumundadır.